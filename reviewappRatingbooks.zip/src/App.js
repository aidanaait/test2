import logo from './logo.svg';
import './App.css';
import Titles from './components/titles';
function App() {
  return (
    <div className="App">
     <Titles/>
    </div>
  );
}

export default App;
