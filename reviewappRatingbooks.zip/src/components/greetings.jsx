import React, { Component } from 'react';

const Greetings = ({name}) => {
    return ( <div>
        <h1>Hello {name}</h1>
    </div> );
}
 
export default Greetings;